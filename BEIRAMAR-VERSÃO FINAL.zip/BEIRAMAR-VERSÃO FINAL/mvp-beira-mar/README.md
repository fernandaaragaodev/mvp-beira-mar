<h2 align="center">🐟 Pescados Beira Mar</h2>


<p align="center">Projeto desenvolvido na disciplina de Residência em Software I, voltado para a construção de um site com objetivo de aprimorar a organização interna da empresa, facilitando o controle dos setores e o acompanhamento das entregas.</p>


<h2 align="center">🛠 Tecnologias e Ferramentas</h2>

###

<p align="center">💻 HTML | CSS | JavaScript <br>

###

<h2 align="center">⚙️ Como executar o site</h2>

<div align="center">
1. Baixe ou clone o repositório para sua máquina<br>
2. Abra a pasta do projeto no Visual Studio Code<br>
3. Instale a extensão do Live Server<br>
4. Abra o arquivo index.html e execute pelo Live Server<br>
</div>
