// Navegação: cuida de trocar páginas e atualizar o título
let currentPage = 'dashboard';

function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (navLinks.length === 0) {
        console.warn('Links de navegação não encontrados');
        return;
    }
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetPage = this.getAttribute('data-page');
            if (targetPage && targetPage !== currentPage) {
                navigateToPage(targetPage);
            }
            
            // Fechar sidebar em mobile após navegação
            if (window.innerWidth <= 768) {
                const sidebar = document.querySelector('.sidebar');
                if (sidebar) {
                    sidebar.classList.remove('open');
                }
            }
        });
    });
}

function navigateToPage(pageName) {
    const navLinks = document.querySelectorAll('.nav-link');
    const pages = document.querySelectorAll('.page');
    const pageTitle = document.getElementById('pageTitle');
    
    // Remove o "active" de todos os links e páginas
    navLinks.forEach(link => {
        link.parentElement.classList.remove('active');
    });
    
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // Marca como "active" o link e a página atuais
    const activeLink = document.querySelector(`[data-page="${pageName}"]`);
    const activePage = document.getElementById(pageName);
    
    if (activeLink && activePage) {
        activeLink.parentElement.classList.add('active');
        activePage.classList.add('active');
        
        // Atualiza o título exibido no cabeçalho
        const pageTitleText = activeLink.querySelector('span').textContent;
        if (pageTitle) {
            pageTitle.textContent = pageTitleText;
        }
        
        // Breadcrumbs por módulo (nível 1)
        if (window.BeiraMarUtils && window.BeiraMarUtils.setBreadcrumbs) {
            window.BeiraMarUtils.setBreadcrumbs([pageTitleText]);
        }
        
        currentPage = pageName;
        
        // Pede para carregar o conteúdo específico da página
        loadPageContent(pageName);
    }
}

function loadPageContent(pageName) {
    switch(pageName) {
        case 'estoque':
            if (window.BeiraMarEstoque && window.BeiraMarEstoque.loadEstoqueContent) {
                window.BeiraMarEstoque.loadEstoqueContent();
            }
            break;
        case 'producao':
            if (window.BeiraMarProducao && window.BeiraMarProducao.loadProducaoContent) {
                window.BeiraMarProducao.loadProducaoContent();
            }
            break;
        case 'vendas':
            if (window.BeiraMarVendas && window.BeiraMarVendas.loadVendasContent) {
                window.BeiraMarVendas.loadVendasContent();
            }
            break;
        case 'fluxo':
            if (window.BeiraMarFluxo && window.BeiraMarFluxo.loadFluxoContent) {
                window.BeiraMarFluxo.loadFluxoContent();
            }
            break;
        case 'notificacoes':
            if (window.BeiraMarNotificacoes && window.BeiraMarNotificacoes.loadNotificacoesContent) {
                window.BeiraMarNotificacoes.loadNotificacoesContent();
            }
            break;
        case 'dashboard':
            if (window.BeiraMarDashboard && window.BeiraMarDashboard.updateDashboardData) {
                window.BeiraMarDashboard.updateDashboardData();
            }
            break;
    }
}

// Exporta a API pública de navegação
window.BeiraMarNavigation = {
    initializeNavigation,
    navigateToPage,
    loadPageContent
};

