// Notificações: montagem do conteúdo e estilos
function loadNotificacoesContent() {
    const notificacoesPage = document.getElementById('notificacoes');
    
    notificacoesPage.innerHTML = `
        <div class="notificacoes-header">
            <h2>Notificações</h2>
            <div class="notificacoes-actions">
                <button class="btn btn-secondary" id="btnMarcarTodasLidas">
                    <i class="fas fa-check-double"></i>
                    Marcar todas como lidas
                </button>
                <button class="btn btn-danger" id="btnLimparNotificacoes">
                    <i class="fas fa-trash"></i>
                    Limpar todas
                </button>
            </div>
        </div>
        
        <div class="notificacoes-container">
            <!-- Será preenchido pelo sistema unificado -->
        </div>
    `;
    
    addNotificacoesStyles();
    
    // Atualiza a página com as notificações do sistema unificado
    if (window.BeiraMarNotifications) {
        window.BeiraMarNotifications.updatePage();
        window.BeiraMarNotifications.updateBadges();
    }
    
    // Event listeners dos botões
    setupNotificacoesHandlers();
}

function addNotificacoesStyles() {
    if (!document.getElementById('notificacoes-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notificacoes-styles';
        styles.textContent = `
            .notificacoes-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .notificacoes-header h2 {
                margin: 0;
                font-size: 1.75rem;
                color: #333;
            }
            
            .notificacoes-actions {
                display: flex;
                gap: 0.75rem;
                flex-wrap: wrap;
            }
            
            .btn {
                padding: 0.65rem 1.25rem;
                border: none;
                border-radius: 8px;
                font-weight: 500;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                transition: all 0.3s ease;
                font-size: 0.9rem;
            }
            
            .btn-secondary {
                background: #6c757d;
                color: white;
            }
            
            .btn-secondary:hover {
                background: #5a6268;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(108,117,125,0.3);
            }
            
            .btn-danger {
                background: #dc3545;
                color: white;
            }
            
            .btn-danger:hover {
                background: #c82333;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(220,53,69,0.3);
            }
            
            .btn i {
                pointer-events: none;
            }
            
            .notificacoes-container {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }
            
            .notificacao-card {
                background: white;
                border-radius: 12px;
                padding: 1.5rem;
                display: flex;
                align-items: flex-start;
                gap: 1rem;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                transition: all 0.3s ease;
                border-left: 4px solid #ddd;
                position: relative;
            }
            
            .notificacao-card.unread {
                background: #f8f9ff;
                box-shadow: 0 2px 12px rgba(0,102,204,0.15);
            }
            
            .notificacao-card.unread::before {
                content: '';
                position: absolute;
                top: 1.5rem;
                right: 1.5rem;
                width: 10px;
                height: 10px;
                background: #0066cc;
                border-radius: 50%;
            }
            
            .notificacao-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 16px rgba(0,0,0,0.15);
            }
            
            /* Cores por tipo */
            .notificacao-card.warning {
                border-left-color: #ffc107;
            }
            
            .notificacao-card.warning .notificacao-icon {
                background: rgba(255, 193, 7, 0.1);
                color: #ffc107;
            }
            
            .notificacao-card.success {
                border-left-color: #28a745;
            }
            
            .notificacao-card.success .notificacao-icon {
                background: rgba(40, 167, 69, 0.1);
                color: #28a745;
            }
            
            .notificacao-card.info {
                border-left-color: #17a2b8;
            }
            
            .notificacao-card.info .notificacao-icon {
                background: rgba(23, 162, 184, 0.1);
                color: #17a2b8;
            }
            
            .notificacao-card.primary {
                border-left-color: #0066cc;
            }
            
            .notificacao-card.primary .notificacao-icon {
                background: rgba(0, 102, 204, 0.1);
                color: #0066cc;
            }
            
            .notificacao-card.default {
                border-left-color: #6c757d;
            }
            
            .notificacao-card.default .notificacao-icon {
                background: rgba(108, 117, 125, 0.1);
                color: #6c757d;
            }
            
            .notificacao-icon {
                width: 48px;
                height: 48px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.25rem;
                flex-shrink: 0;
            }
            
            .notificacao-content {
                flex: 1;
            }
            
            .notificacao-content h4 {
                margin: 0 0 0.5rem 0;
                font-size: 1.1rem;
                font-weight: 600;
                color: #333;
            }
            
            .notificacao-content p {
                margin: 0 0 0.75rem 0;
                color: #666;
                line-height: 1.5;
            }
            
            .notificacao-time {
                display: inline-flex;
                align-items: center;
                gap: 0.4rem;
                font-size: 0.85rem;
                color: #999;
            }
            
            .notificacao-time i {
                font-size: 0.75rem;
            }
            
            .notificacao-actions {
                display: flex;
                gap: 0.5rem;
                flex-shrink: 0;
                margin-top: 0.25rem;
            }
            
            .btn-notif-action {
                width: 36px;
                height: 36px;
                border: none;
                border-radius: 6px;
                background: #f8f9fa;
                color: #666;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s ease;
            }
            
            .btn-notif-action:hover {
                background: #e9ecef;
                color: #0066cc;
                transform: scale(1.1);
            }
            
            .btn-notif-action.btn-notif-danger:hover {
                background: rgba(220, 53, 69, 0.1);
                color: #dc3545;
            }
            
            .btn-notif-action i {
                pointer-events: none;
            }
            
            /* Animação de remoção */
            .notificacao-card.removing {
                opacity: 0;
                transform: translateX(-100%);
                transition: all 0.3s ease;
            }
            
            /* Estado "lida" */
            .notificacao-card.read {
                opacity: 0.7;
            }
            
            .notificacao-card.read::before {
                display: none;
            }
            
            /* Responsivo */
            @media (max-width: 768px) {
                .notificacoes-header {
                    flex-direction: column;
                    align-items: flex-start;
                }
                
                .notificacoes-actions {
                    width: 100%;
                }
                
                .notificacoes-actions .btn {
                    flex: 1;
                }
                
                .notificacao-card {
                    padding: 1rem;
                    flex-direction: column;
                }
                
                .notificacao-icon {
                    width: 40px;
                    height: 40px;
                    font-size: 1rem;
                }
                
                .notificacao-actions {
                    width: 100%;
                    justify-content: flex-end;
                }
            }
        `;
        document.head.appendChild(styles);
    }
}

function setupNotificacoesHandlers() {
    // Marcar todas como lidas
    const btnMarcarTodas = document.getElementById('btnMarcarTodasLidas');
    if (btnMarcarTodas) {
        btnMarcarTodas.addEventListener('click', function() {
            if (window.BeiraMarNotifications) {
                window.BeiraMarNotifications.markAllAsRead();
                alert('Todas as notificações foram marcadas como lidas!');
            }
        });
    }
    
    // Limpar todas as notificações
    const btnLimpar = document.getElementById('btnLimparNotificacoes');
    if (btnLimpar) {
        btnLimpar.addEventListener('click', function() {
            if (confirm('Tem certeza que deseja remover todas as notificações?')) {
                if (window.BeiraMarNotifications) {
                    window.BeiraMarNotifications.removeAll();
                }
            }
        });
    }
}

// Exporta função para uso global
window.BeiraMarNotificacoes = {
    loadNotificacoesContent,
    initializeNotificacoes: loadNotificacoesContent
};
