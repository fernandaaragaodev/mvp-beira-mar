// Utilitários globais do sistema

// Formata valores monetários para BRL
function formatCurrencyBR(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

// Formata números com separador de milhar
function formatNumberBR(value) {
    return new Intl.NumberFormat('pt-BR').format(value);
}

// Exibe notificação toast
function showToast(message, type = 'info') {
    console.log(`[${type.toUpperCase()}] ${message}`);
}

// Exporta tabela para CSV
function exportTableToCSV(table, filename) {
    const rows = table.querySelectorAll('tr');
    const csv = [];
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td, th');
        const rowData = [];
        cols.forEach(col => rowData.push(col.innerText));
        csv.push(rowData.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
}

// Store de preços de produtos (para estoque)
const ProductPriceStore = {
    prices: {},
    
    setPrice(productName, price) {
        this.prices[productName] = parseFloat(price);
    },
    
    getPrice(productName) {
        return this.prices[productName] || null;
    }
};

// Sistema Global de Notificações UNIFICADO
window.BeiraMarNotifications = {
    // Dados centralizados de notificações
    notifications: [
        { id: 1, type: 'warning', icon: 'fa-exclamation-triangle', title: 'Estoque Baixo', text: 'Tilápia Inteira está com estoque baixo (25kg restantes)', time: 'há 15 minutos', unread: true },
        { id: 2, type: 'success', icon: 'fa-check-circle', title: 'Pedido Entregue', text: 'Pedido #1234 foi entregue com sucesso no Restaurante Mar Azul', time: 'há 1 hora', unread: true },
        { id: 3, type: 'info', icon: 'fa-info-circle', title: 'Atualização do Sistema', text: 'Sistema atualizado com sucesso. Novas funcionalidades disponíveis.', time: 'há 3 horas', unread: true },
        { id: 4, type: 'primary', icon: 'fa-shopping-cart', title: 'Novo Pedido', text: 'Pedido #1235 recebido de Churrascaria Boi na Brasa - 50kg de Picanha', time: 'há 5 horas', unread: false },
        { id: 5, type: 'default', icon: 'fa-bell', title: 'Lembrete', text: 'Reunião com fornecedores agendada para amanhã às 14h', time: 'há 1 dia', unread: false },
        { id: 6, type: 'success', icon: 'fa-dollar-sign', title: 'Pagamento Recebido', text: 'Pagamento de R$ 2.450,00 do Restaurante Mar Azul foi confirmado', time: 'há 2 dias', unread: false },
        { id: 7, type: 'warning', icon: 'fa-tools', title: 'Manutenção Agendada', text: 'Manutenção preventiva da Câmara Fria A agendada para sexta-feira', time: 'há 3 dias', unread: false },
        { id: 8, type: 'primary', icon: 'fa-user-plus', title: 'Novo Cliente', text: 'Novo cliente cadastrado: Peixaria do Porto - Zona Portuária', time: 'há 4 dias', unread: false }
    ],
    
    // Retorna todas as notificações
    getAll: function() {
        return this.notifications;
    },
    
    // Retorna apenas não lidas
    getUnread: function() {
        return this.notifications.filter(n => n.unread);
    },
    
    // Conta não lidas
    getUnreadCount: function() {
        return this.notifications.filter(n => n.unread).length;
    },
    
    // Marca uma notificação como lida
    markAsRead: function(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            notification.unread = false;
            this.updateBadges();
            this.updateDropdown();
            this.updatePage();
        }
    },
    
    // Marca todas como lidas
    markAllAsRead: function() {
        this.notifications.forEach(n => n.unread = false);
        this.updateBadges();
        this.updateDropdown();
        this.updatePage();
    },
    
    // Remove uma notificação
    remove: function(id) {
        const index = this.notifications.findIndex(n => n.id === id);
        if (index !== -1) {
            this.notifications.splice(index, 1);
            this.updateBadges();
            this.updateDropdown();
            this.updatePage();
        }
    },
    
    // Remove todas as notificações
    removeAll: function() {
        this.notifications = [];
        this.updateBadges();
        this.updateDropdown();
        this.updatePage();
    },
    
    // Atualiza os badges (header e sidebar)
    updateBadges: function() {
        const unreadCount = this.getUnreadCount();
        
        console.log('🔄 Atualizando badges - não lidas:', unreadCount);
        
        // Badge do header (sino) - DENTRO DO BOTÃO
        const headerBadge = document.querySelector('.notification-btn .notification-count');
        if (headerBadge) {
            if (unreadCount > 0) {
                headerBadge.textContent = unreadCount;
                headerBadge.style.display = 'inline-flex';
            } else {
                headerBadge.style.display = 'none';
            }
            console.log('✅ Badge do header atualizado:', unreadCount);
        } else {
            console.warn('⚠️ Badge do header não encontrado');
        }
        
        // Badge da sidebar
        const sidebarBadge = document.querySelector('.nav-link[data-page="notificacoes"] .notification-badge');
        if (sidebarBadge) {
            if (unreadCount > 0) {
                sidebarBadge.textContent = unreadCount;
                sidebarBadge.style.display = 'inline-flex';
            } else {
                sidebarBadge.style.display = 'none';
            }
            console.log('✅ Badge da sidebar atualizado:', unreadCount);
        } else {
            console.warn('⚠️ Badge da sidebar não encontrado');
        }
    },
    
    // Atualiza o dropdown do header
    updateDropdown: function() {
        const dropdownList = document.querySelector('.notifications-list');
        if (!dropdownList) {
            console.warn('⚠️ Lista do dropdown não encontrada');
            return;
        }
        
        const notifications = this.getAll().slice(0, 5); // Apenas 5 mais recentes
        
        if (notifications.length === 0) {
            dropdownList.innerHTML = '<div class="notifications-empty"><i class="fas fa-inbox"></i><p>Nenhuma notificação</p></div>';
            return;
        }
        
        dropdownList.innerHTML = notifications.map(n => `
            <div class="notification-item ${n.unread ? 'unread' : ''}" data-id="${n.id}">
                <div class="notification-item-icon ${n.type}">
                    <i class="fas ${n.icon}"></i>
                </div>
                <div class="notification-item-content">
                    <p class="notification-item-title">${n.title}</p>
                    <p class="notification-item-text">${n.text}</p>
                    <span class="notification-item-time">${n.time}</span>
                </div>
            </div>
        `).join('');
        
        // Re-adiciona event listeners
        this.attachDropdownEvents();
        
        console.log('✅ Dropdown atualizado com', notifications.length, 'notificações');
    },
    
    // Atualiza a página de notificações
    updatePage: function() {
        const pageContainer = document.querySelector('.notificacoes-container');
        if (!pageContainer) {
            console.warn('⚠️ Container da página não encontrado');
            return;
        }
        
        const notifications = this.getAll();
        
        if (notifications.length === 0) {
            pageContainer.innerHTML = '<div style="text-align: center; padding: 3rem; color: #999;"><i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i><p>Nenhuma notificação</p></div>';
            return;
        }
        
        pageContainer.innerHTML = notifications.map(n => `
            <div class="notificacao-card ${n.type} ${n.unread ? 'unread' : ''}" data-id="${n.id}">
                <div class="notificacao-icon">
                    <i class="fas ${n.icon}"></i>
                </div>
                <div class="notificacao-content">
                    <h4>${n.title}</h4>
                    <p>${n.text}</p>
                    <span class="notificacao-time"><i class="fas fa-clock"></i> ${n.time}</span>
                </div>
                <div class="notificacao-actions">
                    <button class="btn-notif-action btn-mark-read" title="Marcar como lida" data-id="${n.id}"><i class="fas fa-check"></i></button>
                    <button class="btn-notif-action btn-notif-danger btn-delete" title="Remover" data-id="${n.id}"><i class="fas fa-times"></i></button>
                </div>
            </div>
        `).join('');
        
        // Re-adiciona event listeners
        this.attachPageEvents();
        
        console.log('✅ Página atualizada com', notifications.length, 'notificações');
    },
    
    // Adiciona event listeners no dropdown
    attachDropdownEvents: function() {
        const items = document.querySelectorAll('.notifications-dropdown .notification-item');
        items.forEach(item => {
            item.addEventListener('click', (e) => {
                const id = parseInt(item.dataset.id);
                this.markAsRead(id);
                
                // Fecha dropdown
                const dropdown = document.querySelector('.notifications-dropdown');
                const btn = document.querySelector('.notification-btn');
                if (dropdown) dropdown.classList.remove('show');
                if (btn) btn.classList.remove('active');
                
                // Navega para página de notificações
                if (window.BeiraMar && window.BeiraMar.navigateToPage) {
                    window.BeiraMar.navigateToPage('notificacoes');
                }
            });
        });
        
        console.log('✅ Event listeners do dropdown adicionados');
    },
    
    // Adiciona event listeners na página
    attachPageEvents: function() {
        // Botões de marcar como lida
        const markReadBtns = document.querySelectorAll('.btn-mark-read');
        markReadBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                this.markAsRead(id);
            });
        });
        
        // Botões de deletar
        const deleteBtns = document.querySelectorAll('.btn-delete');
        deleteBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                const card = btn.closest('.notificacao-card');
                card.classList.add('removing');
                setTimeout(() => {
                    this.remove(id);
                }, 300);
            });
        });
        
        console.log('✅ Event listeners da página adicionados');
    }
};

// Exporta utilitários
window.BeiraMarUtils = {
    formatCurrencyBR,
    formatNumberBR,
    showToast,
    exportTableToCSV,
    ProductPriceStore
};
