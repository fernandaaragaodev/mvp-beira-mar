// =========================================
// DASHBOARD - INTELLIGENT CLEAN UI AZUL
// =========================================

function loadDashboardContent() {
    const dashboard = document.getElementById('dashboard');
    
    // 1. Coleta dados em tempo real das outras variáveis globais
    const dados = getRealTimeData();

    dashboard.innerHTML = `
        <div class="welcome-banner">
            <div>
                <h1>Visão Geral</h1>
                <p>Resumo das operações em tempo real</p>
            </div>
            <div class="date-badge">
                <i class="fas fa-calendar-alt"></i> ${new Date().toLocaleDateString('pt-BR')}
            </div>
        </div>

        <div class="dash-cards">
            
            <div class="d-card card-blue" onclick="navigateTo('estoque')">
                <div class="d-card-info">
                    <h3>Itens em Estoque</h3>
                    <p class="d-number">${dados.estoque.totalItens}</p>
                    <span class="d-status"><i class="fas fa-exclamation-circle"></i> ${dados.estoque.criticos} itens críticos</span>
                </div>
                <div class="d-icon"><i class="fas fa-boxes"></i></div>
            </div>

            <div class="d-card card-green" onclick="navigateTo('vendas')">
                <div class="d-card-info">
                    <h3>Vendas Hoje</h3>
                    <p class="d-number">${dados.vendas.totalHoje}</p>
                    <span class="d-status"><i class="fas fa-clock"></i> ${dados.vendas.pendentes} pedidos pendentes</span>
                </div>
                <div class="d-icon"><i class="fas fa-chart-line"></i></div>
            </div>

            <div class="d-card card-purple" onclick="navigateTo('producao')">
                <div class="d-card-info">
                    <h3>Em Produção</h3>
                    <p class="d-number">${dados.producao.ativos}</p>
                    <span class="d-status"><i class="fas fa-industry"></i> Lotes ativos na fábrica</span>
                </div>
                <div class="d-icon"><i class="fas fa-fish"></i></div>
            </div>

            <div class="d-card card-orange" onclick="navigateTo('producao')"> <div class="d-card-info">
                    <h3>Logística</h3>
                    <p class="d-number">${dados.logistica.ativos}</p>
                    <span class="d-status"><i class="fas fa-truck"></i> Entregas em andamento</span>
                </div>
                <div class="d-icon"><i class="fas fa-shipping-fast"></i></div>
            </div>
        </div>

        <div class="dash-grid-bottom">
            
            <div class="activity-section">
                <div class="section-header">
                    <h3><i class="fas fa-bell"></i> Atividades Recentes</h3>
                </div>
                <div class="activity-list">
                    ${gerarNotificacoesHTML(dados)}
                </div>
            </div>

            <div class="shortcuts-section">
                <div class="section-header">
                    <h3><i class="fas fa-bolt"></i> Ações Rápidas</h3>
                </div>
                <div class="shortcuts-grid">
                    <button class="shortcut-btn" onclick="navigateTo('vendas', 'novo')">
                        <div class="s-icon"><i class="fas fa-cart-plus"></i></div>
                        <span>Novo Pedido</span>
                    </button>
                    <button class="shortcut-btn" onclick="navigateTo('producao', 'novo')">
                        <div class="s-icon"><i class="fas fa-box-open"></i></div>
                        <span>Novo Lote</span>
                    </button>
                    <button class="shortcut-btn" onclick="navigateTo('estoque', 'novo')">
                        <div class="s-icon"><i class="fas fa-plus-circle"></i></div>
                        <span>Add Estoque</span>
                    </button>
                </div>
            </div>
        </div>
    `;

    addDashboardStyles();
}

// --- FUNÇÕES DE INTEGRAÇÃO DE DADOS ---

function getRealTimeData() {
    // 1. ESTOQUE (Tenta pegar de estoqueGlobal ou itensPadroes se vazio)
    // Precisamos garantir que estamos lendo a variável global definida em estoque.js
    let listaEstoque = (typeof estoqueAtual !== 'undefined') ? estoqueAtual : [];
    if (listaEstoque.length === 0 && typeof itensPadroes !== 'undefined') listaEstoque = itensPadroes; // Fallback
    
    const estoqueTotal = listaEstoque.length;
    const estoqueCriticos = listaEstoque.filter(i => i.status === 'Crítico').length;

    // 2. VENDAS
    let listaVendas = (typeof vendasData !== 'undefined') ? vendasData : [];
    let valorHoje = 0;
    let pendentes = 0;
    let ultimoPedido = null;

    listaVendas.forEach(v => {
        if (v.status === 'Concluído' && v.data.includes('Hoje')) {
            valorHoje += v.valor;
        }
        if (v.status === 'Pendente' || v.status === 'Em Separação') {
            pendentes++;
        }
    });
    
    // Pega o último pedido inserido (maior ID)
    if (listaVendas.length > 0) {
        ultimoPedido = listaVendas[listaVendas.length - 1];
    }

    // 3. PRODUÇÃO
    let listaProducao = (typeof producaoItems !== 'undefined') ? producaoItems : [];
    const producaoAtiva = listaProducao.length;
    let ultimoLote = listaProducao.length > 0 ? listaProducao[listaProducao.length - 1] : null;

    // 4. LOGÍSTICA
    let listaLogistica = (typeof logisticaItems !== 'undefined') ? logisticaItems : [];
    const logisticaAtiva = listaLogistica.length;

    return {
        estoque: { totalItens: estoqueTotal, criticos: estoqueCriticos },
        vendas: { totalHoje: valorHoje.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'}), pendentes: pendentes, ultimo: ultimoPedido },
        producao: { ativos: producaoAtiva, ultimo: ultimoLote },
        logistica: { ativos: logisticaAtiva }
    };
}

function gerarNotificacoesHTML(dados) {
    let html = '';

    // Notificação de Venda Recente
    if (dados.vendas.ultimo) {
        html += `
            <div class="activity-item">
                <div class="act-icon green"><i class="fas fa-shopping-bag"></i></div>
                <div class="act-content">
                    <h4>Nova Venda Registrada</h4>
                    <p>Pedido #${dados.vendas.ultimo.id} - ${dados.vendas.ultimo.cliente}</p>
                    <span class="act-time">${dados.vendas.ultimo.data}</span>
                </div>
            </div>
        `;
    } else {
        // Fallback padrão se não tiver dados
        html += `
            <div class="activity-item">
                <div class="act-icon green"><i class="fas fa-shopping-bag"></i></div>
                <div class="act-content">
                    <h4>Sistema Iniciado</h4>
                    <p>Módulo de vendas pronto para operar.</p>
                    <span class="act-time">Agora</span>
                </div>
            </div>
        `;
    }

    // Notificação de Produção Recente
    if (dados.producao.ultimo) {
        html += `
            <div class="activity-item">
                <div class="act-icon blue"><i class="fas fa-industry"></i></div>
                <div class="act-content">
                    <h4>Lote em Produção</h4>
                    <p>${dados.producao.ultimo.titulo}</p>
                    <span class="act-time">${dados.producao.ultimo.data}</span>
                </div>
            </div>
        `;
    }

    // Alerta de Estoque Crítico (se houver)
    if (dados.estoque.criticos > 0) {
        html += `
            <div class="activity-item">
                <div class="act-icon red"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="act-content">
                    <h4>Alerta de Estoque</h4>
                    <p>Existem ${dados.estoque.criticos} produtos com estoque baixo.</p>
                    <span class="act-time">Atenção Necessária</span>
                </div>
            </div>
        `;
    }

    return html;
}

// Navegação Helper (Simula clique no menu)
window.navigateTo = function(pageId, action = null) {
    // 1. Troca a página visualmente
    if (window.BeiraMarNavigation && window.BeiraMarNavigation.navigateToPage) {
        window.BeiraMarNavigation.navigateToPage(pageId);
    } else {
        // Fallback caso a navegação global não esteja carregada
        console.log(`Navegando para: ${pageId}`);
        // Tenta achar a função de carga
        if(pageId === 'estoque' && window.BeiraMarEstoque) window.BeiraMarEstoque.loadEstoqueContent();
        if(pageId === 'vendas' && window.BeiraMarVendas) window.BeiraMarVendas.loadVendasContent();
        if(pageId === 'producao' && window.BeiraMarProducao) window.BeiraMarProducao.loadProducaoContent();
    }

    // 2. Se tiver ação (ex: 'novo'), tenta abrir o modal correspondente após um pequeno delay
    if (action === 'novo') {
        setTimeout(() => {
            if(pageId === 'vendas' && window.abrirModalNovoPedido) window.abrirModalNovoPedido();
            if(pageId === 'producao' && window.abrirModalNovoLote) window.abrirModalNovoLote();
            if(pageId === 'estoque' && document.getElementById('btnAdicionarItem')) document.getElementById('btnAdicionarItem').click();
        }, 300);
    }
}

// --- CSS DASHBOARD ---

function addDashboardStyles() {
    if (!document.getElementById('dashboard-styles')) {
        const styles = document.createElement('style');
        styles.id = 'dashboard-styles';
        styles.textContent = `
            :root {
                --dash-primary: #0066cc;
                --dash-text: #2c3e50;
                --dash-shadow: 0 4px 15px rgba(0,0,0,0.05);
            }

            /* Banner */
            .welcome-banner {
                display: flex; justify-content: space-between; align-items: flex-end;
                margin-bottom: 2rem; border-bottom: 1px solid #eee; padding-bottom: 1rem;
            }
            .welcome-banner h1 { margin: 0; font-size: 1.8rem; color: var(--dash-text); font-weight: 700; }
            .welcome-banner p { margin: 0; color: #7f8c8d; font-size: 0.95rem; }
            .date-badge {
                background: #f0f7ff; color: var(--dash-primary); padding: 0.5rem 1rem;
                border-radius: 50px; font-weight: 600; font-size: 0.9rem;
            }

            /* Cards Principais */
            .dash-cards {
                display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
                gap: 1.5rem; margin-bottom: 2rem;
            }
            .d-card {
                background: white; border-radius: 16px; padding: 1.5rem;
                box-shadow: var(--dash-shadow); position: relative; overflow: hidden;
                cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;
                border-left: 5px solid #ccc;
            }
            .d-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
            
            /* Cores dos Cards */
            .card-blue { border-left-color: #0066cc; }
            .card-green { border-left-color: #28a745; }
            .card-purple { border-left-color: #8e44ad; }
            .card-orange { border-left-color: #f39c12; }

            .d-card-info h3 { font-size: 0.85rem; text-transform: uppercase; color: #7f8c8d; margin: 0 0 0.5rem 0; }
            .d-number { font-size: 2rem; font-weight: 800; color: var(--dash-text); margin: 0 0 0.5rem 0; }
            .d-status { font-size: 0.8rem; color: #95a5a6; display: flex; align-items: center; gap: 0.3rem; }
            
            .d-icon {
                position: absolute; right: 15px; bottom: 10px; font-size: 3.5rem;
                opacity: 0.08; color: #333; pointer-events: none;
            }

            /* Grid Inferior */
            .dash-grid-bottom {
                display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;
            }

            /* Seções */
            .activity-section, .shortcuts-section {
                background: white; border-radius: 16px; padding: 1.5rem;
                box-shadow: var(--dash-shadow); height: 100%;
            }
            .section-header { margin-bottom: 1.5rem; border-bottom: 1px solid #f0f0f0; padding-bottom: 0.8rem; }
            .section-header h3 { margin: 0; font-size: 1.1rem; color: var(--dash-text); display: flex; align-items: center; gap: 0.5rem; }

            /* Lista de Atividades */
            .activity-list { display: flex; flex-direction: column; gap: 1rem; }
            .activity-item {
                display: flex; gap: 1rem; align-items: flex-start;
                padding: 0.8rem; border-radius: 12px; background: #f9f9f9;
                transition: 0.2s;
            }
            .activity-item:hover { background: #f0f7ff; }
            
            .act-icon {
                width: 40px; height: 40px; border-radius: 50%; display: flex;
                align-items: center; justify-content: center; color: white; flex-shrink: 0;
            }
            .act-icon.green { background: linear-gradient(135deg, #28a745, #2ecc71); }
            .act-icon.blue { background: linear-gradient(135deg, #0066cc, #0099ff); }
            .act-icon.red { background: linear-gradient(135deg, #e74c3c, #c0392b); }

            .act-content h4 { margin: 0; font-size: 0.95rem; color: #333; }
            .act-content p { margin: 0.2rem 0; font-size: 0.85rem; color: #666; }
            .act-time { font-size: 0.75rem; color: #999; font-style: italic; }

            /* Botões de Atalho */
            .shortcuts-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
            .shortcut-btn {
                display: flex; align-items: center; gap: 1rem; padding: 1rem;
                border: 2px solid #f0f0f0; border-radius: 12px; background: white;
                cursor: pointer; transition: 0.2s; text-align: left;
            }
            .shortcut-btn:hover { border-color: var(--dash-primary); background: #f8fbff; transform: translateX(5px); }
            
            .s-icon {
                width: 35px; height: 35px; background: #eef6ff; color: var(--dash-primary);
                border-radius: 8px; display: flex; align-items: center; justify-content: center;
                font-size: 1.1rem;
            }
            .shortcut-btn span { font-weight: 600; color: #555; }

            @media (max-width: 768px) {
                .dash-grid-bottom { grid-template-columns: 1fr; }
                .dash-cards { grid-template-columns: 1fr; }
                .welcome-banner { flex-direction: column; align-items: flex-start; gap: 1rem; }
            }
        `;
        document.head.appendChild(styles);
    }
}

window.BeiraMarDashboard = { loadDashboardContent, addDashboardStyles };