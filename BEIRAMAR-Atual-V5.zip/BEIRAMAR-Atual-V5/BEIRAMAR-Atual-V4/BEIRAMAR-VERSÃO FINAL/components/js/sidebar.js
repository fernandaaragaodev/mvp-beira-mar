// Sidebar: controle de abrir/fechar e estado
let sidebarCollapsed = window.innerWidth <= 1024;

function initializeSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    if (!sidebar || !sidebarToggle) {
        console.warn('Elementos da sidebar não encontrados');
        return;
    }
    
    if (sidebarCollapsed && window.innerWidth > 768) {
        sidebar.classList.add('collapsed');
        const sidebarContainer = document.getElementById('sidebar-container');
        const appContainer = document.querySelector('.app-container');
        sidebarContainer?.classList.add('collapsed');
        appContainer?.classList.add('sidebar-collapsed');
    }
    
    sidebarToggle.addEventListener('click', toggleSidebar);
    
    // Também permite recolher/expandir clicando na logo
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.style.cursor = 'pointer';
        logo.addEventListener('click', toggleSidebar);
    }

    // No header temos a imagem da marca; em mobile ela deve abrir o sidebar como overlay
    const brandLogo = document.getElementById('brandLogo');
    if (brandLogo) {
        // Ao clicar no brand, abre/fecha o sidebar em mobile
        brandLogo.addEventListener('click', function() {
            const viewportMobile = window.innerWidth <= 768;
            if (!viewportMobile) return; // só atua em mobile

            const sb = document.querySelector('.sidebar');
            const sidebarContainer = document.getElementById('sidebar-container');
            const appContainer = document.querySelector('.app-container');
            if (!sb) return;

            // Abrir como overlay
            sb.classList.toggle('open');
            sidebarContainer?.classList.toggle('open');
            appContainer?.classList.toggle('sidebar-open');

            if (sb.classList.contains('open')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        });

        // Também permitir abrir com Enter/Space para acessibilidade
        brandLogo.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                brandLogo.click();
            }
        });
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const sidebarContainer = document.getElementById('sidebar-container');
    const appContainer = document.querySelector('.app-container');
    if (!sidebar) return;
    
    if (window.innerWidth <= 768) {
        sidebar.classList.toggle('open');
        sidebarContainer?.classList.toggle('open');
        // Marca app como com sidebar aberta em mobile para facilitar regras CSS
        const appContainer = document.querySelector('.app-container');
        appContainer?.classList.toggle('sidebar-open');
        // Controla overflow do body para evitar scroll no background quando aberto
        if (sidebar.classList.contains('open')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    } else {
        // Tablet: não permitir expandir — manter apenas ícones (collapsed)
        if (window.innerWidth <= 1024) {
            sidebar.classList.add('collapsed');
            sidebarContainer?.classList.add('collapsed');
            appContainer?.classList.add('sidebar-collapsed');
            sidebarCollapsed = true;
        } else {
            // Desktop: comportamento normal de toggle
            sidebar.classList.toggle('collapsed');
            sidebarContainer?.classList.toggle('collapsed');
            appContainer?.classList.toggle('sidebar-collapsed');
            sidebarCollapsed = sidebar.classList.contains('collapsed');
        }
    }

    // Atualiza a variável CSS --sidebar-current imediatamente para garantir que
    // todos os elementos que dependem dela se ajustem sem depender só de regras de classe.
    const root = document.documentElement;
    const computed = getComputedStyle(root);
    const collapsedVal = computed.getPropertyValue('--sidebar-collapsed') || '96px';
    const widthVal = computed.getPropertyValue('--sidebar-width') || '280px';
    const app = document.querySelector('.app-container');
    if (app) {
        if (app.classList.contains('sidebar-open')) {
            app.style.setProperty('--sidebar-current', '0px');
        } else if (app.classList.contains('sidebar-collapsed')) {
            app.style.setProperty('--sidebar-current', collapsedVal.trim());
        } else {
            app.style.setProperty('--sidebar-current', widthVal.trim());
        }
    }
}

// Exporta a API pública da Sidebar
window.BeiraMarSidebar = {
    initializeSidebar,
    toggleSidebar
};

